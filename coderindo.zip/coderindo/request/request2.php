<?php

$cari = new pencarian();

echo $cari->cari($keywo, $mulai, $batas);
