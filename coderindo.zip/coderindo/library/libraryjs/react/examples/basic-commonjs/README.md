# Basic example of using React with Browserify

Run `npm install` in the directory to install React from npm. Then run:

```sh
npm start
```

to produce `bundle.js` with example code and React.
