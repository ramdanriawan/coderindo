<!DOCTYPE html>
<html>
<head>
  <title><?php include "judul.php"; ?></title>
  <link href="/css/cssutama.css" rel="stylesheet" type="text/css"/>
<script src="/library/libraryjs/jquery/jquery.js"></script>
<script src="/script/function.js"></script>
<script src=/library/libraryjs/highlight/highlight.js></script>
<link rel="stylesheet" href="/library/libraryjs/highlight/highlight.css" />
<link rel="stylesheet" type="text/css" href="/css/style.css">
<script>hljs.initHighlightingOnLoad();</script>
</head>
<form class="" action="/cari/" method="get">
  <input type="text" name="keywo">
  <input type="submit">
</form>
